//package CompanyAssignment.StreamTask;

import java.time.LocalDate;

public class Salary {
    private int id;
    private int salary;
    private int month;
    private int year;
    LocalDate date;

    public Salary(int id, int salary, int month, int year) {
        this.id = id;
        this.salary = salary;
        this.month = month;
        this.year = year;
    }
    public int getId() {
        return id;
    }

    public int getSalary() {
        return salary;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }
}
